public class Node
{
	int		data;	// this will contain a number
	Node	next;  // this is NULL by default
	


}

